import  React,{useState, useEffect,Component}from 'react';
import logoImg  from '../../assets/logo.png';
import {FiPower,FiTrash2}  from 'react-icons/fi';
import {Link, useHistory }  from 'react-router-dom';
import './style.css';
import api from '../../services/api';
import {TabMenu} from 'primereact/tabmenu'
import ReactDOM from 'react-dom';

export class TabMenuDemo extends Component {

    constructor(props) {
        super(props);

        this.items =  [
            {label: 'Home', icon: 'pi pi-fw pi-home'},
            {label: 'Calendar', icon: 'pi pi-fw pi-calendar'},
            {label: 'Edit', icon: 'pi pi-fw pi-pencil'},
            {label: 'Documentation', icon: 'pi pi-fw pi-file'},
            {label: 'Settings', icon: 'pi pi-fw pi-cog'}
        ];
    }

    render() {
        return (
            <div>
                <TabMenu model={this.items} />
            </div>
        );
    }
}
                




export default function Profile (){
    const [incidents, setIncidents]= useState([]);
    const history = useHistory();
    const ongId  =  localStorage.getItem('ongId');
    const ongName = localStorage.getItem('ongName');

    useEffect (() => {
        api.get('profile',{
            headers :{
                Authorization: ongId
            }
        }).then(response =>{
            setIncidents(response.data);

        })
    }, [ongId]);
   async function  handleDeleteIncidente(id){
        try {
            await api.delete(`incidents/${id}`,{
                headers : {
                    Authorization : ongId,
                }


            });
        setIncidents (incidents.filter(incident => incident.id !== id ))
        }catch (err){
            alert('Erro ao deletar casa, tente novamente.');
        }
    }
    function handleLogout (){
        localStorage.clear();
        history.push('/');           
    }
    return (
        <div className="profile-container">
            <header>
                <img src={ logoImg } alt = "Be The hero " />
                 <span> Bem vinda,Altimus </span>

                <Link  className="button" to="incidentes/new"> Cadastrar novo caso </Link>
                <button onClick ={handleLogout} type="button" >
                <FiPower  size={ 18 } color = "#E02141" />
                </button>
            </header>
        <h1>Casos cadastrados </h1>
           <p></p> 
                
            

        </div>




    );

}